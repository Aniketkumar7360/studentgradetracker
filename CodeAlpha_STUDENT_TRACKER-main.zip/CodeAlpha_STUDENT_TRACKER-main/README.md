# CodeAlpha_STUDENT_TRACKER
Student Grade Tracker Java program for teachers to input and analyze student grades. Calculates average, highest, and lowest scores. User-friendly and versatile.
